<?php

namespace Vich\UploaderBundle\Exception;

interface VichUploaderExceptionInterface extends \Throwable
{
}
