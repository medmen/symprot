<?php

namespace Vich\UploaderBundle\Exception;

final class NameGenerationException extends \RuntimeException implements VichUploaderExceptionInterface
{
}
