<?php

namespace Vich\UploaderBundle\Exception;

final class NoFileFoundException extends \RuntimeException implements VichUploaderExceptionInterface
{
}
