CHANGELOG
=========

6.3
---

 * Deprecate the bridge

4.2.0
-----

 * allowed creating lazy-proxies from interfaces

3.3.0
-----

 * [BC BREAK] The `ProxyDumper` class is now final

2.3.0
-----

 * First introduction of `Symfony\Bridge\ProxyManager`
