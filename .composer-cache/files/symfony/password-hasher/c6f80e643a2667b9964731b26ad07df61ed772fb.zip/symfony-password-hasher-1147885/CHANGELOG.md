CHANGELOG
=========

6.2
---

 * Use `SensitiveParameter` attribute to redact sensitive values in back traces

5.3
---

 * Add the component
 * Use `bcrypt` as default algorithm in `NativePasswordHasher`
