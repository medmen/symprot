<?php

return [
    'Names' => [
        'DOP' => [
            0 => 'RD$',
            1 => 'peso dominicano',
        ],
        'USD' => [
            0 => 'US$',
            1 => 'dólar estadounidense',
        ],
    ],
];
