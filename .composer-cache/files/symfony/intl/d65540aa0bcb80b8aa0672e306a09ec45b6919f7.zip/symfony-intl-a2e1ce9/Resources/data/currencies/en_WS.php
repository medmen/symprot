<?php

return [
    'Names' => [
        'WST' => [
            0 => 'WS$',
            1 => 'Samoan Tala',
        ],
    ],
];
