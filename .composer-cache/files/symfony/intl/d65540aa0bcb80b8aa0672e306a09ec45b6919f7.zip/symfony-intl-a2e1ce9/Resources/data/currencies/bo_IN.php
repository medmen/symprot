<?php

return [
    'Names' => [
        'CNY' => [
            0 => 'CN¥',
            1 => 'ཡུ་ཨན་',
        ],
    ],
];
