<?php

return [
    'Names' => [
        'BRL' => [
            0 => 'R$',
            1 => 'real brasileño',
        ],
    ],
];
