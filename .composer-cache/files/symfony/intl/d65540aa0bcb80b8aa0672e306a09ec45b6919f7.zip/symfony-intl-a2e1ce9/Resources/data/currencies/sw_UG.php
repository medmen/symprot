<?php

return [
    'Names' => [
        'UGX' => [
            0 => 'USh',
            1 => 'Shilingi ya Uganda',
        ],
    ],
];
