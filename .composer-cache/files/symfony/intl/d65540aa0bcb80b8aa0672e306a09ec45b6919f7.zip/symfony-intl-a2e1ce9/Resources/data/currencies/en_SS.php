<?php

return [
    'Names' => [
        'GBP' => [
            0 => 'GB£',
            1 => 'British Pound',
        ],
        'SSP' => [
            0 => '£',
            1 => 'South Sudanese Pound',
        ],
    ],
];
