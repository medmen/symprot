<?php

return [
    'Names' => [
        'KYD' => [
            0 => '$',
            1 => 'Cayman Islands Dollar',
        ],
    ],
];
