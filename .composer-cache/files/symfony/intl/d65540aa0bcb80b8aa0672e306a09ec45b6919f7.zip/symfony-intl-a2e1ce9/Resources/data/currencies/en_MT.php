<?php

return [
    'Names' => [
        'GBP' => [
            0 => 'GB£',
            1 => 'British Pound',
        ],
    ],
];
