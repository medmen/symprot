<?php

return [
    'Names' => [
        'WST' => [
            'WS$',
            'Samoan Tala',
        ],
    ],
];
