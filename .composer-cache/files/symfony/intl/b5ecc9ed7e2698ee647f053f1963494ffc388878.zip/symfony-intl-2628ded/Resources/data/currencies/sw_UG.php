<?php

return [
    'Names' => [
        'UGX' => [
            'USh',
            'Shilingi ya Uganda',
        ],
    ],
];
