<?php

return [
    'Names' => [
        'bn' => 'Bengali',
    ],
    'LocalizedNames' => [],
];
