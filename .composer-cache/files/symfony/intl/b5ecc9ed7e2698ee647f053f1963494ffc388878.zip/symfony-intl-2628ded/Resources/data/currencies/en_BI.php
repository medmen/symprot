<?php

return [
    'Names' => [
        'BIF' => [
            'FBu',
            'Burundian Franc',
        ],
    ],
];
