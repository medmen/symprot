<?php

return [
    'Names' => [
        'SGD' => [
            '$',
            'Dolar Singapura',
        ],
    ],
];
