<?php

return [
    'Names' => [
        'DZD' => [
            'DA',
            'dinar algérien',
        ],
    ],
];
