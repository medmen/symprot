<?php

return [
    'Names' => [
        'USD' => [
            '$',
            'Amerikaanse dollar',
        ],
    ],
];
