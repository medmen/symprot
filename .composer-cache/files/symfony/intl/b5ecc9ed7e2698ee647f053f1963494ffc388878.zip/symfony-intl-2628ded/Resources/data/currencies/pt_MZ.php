<?php

return [
    'Names' => [
        'MZN' => [
            'MTn',
            'metical moçambicano',
        ],
    ],
];
