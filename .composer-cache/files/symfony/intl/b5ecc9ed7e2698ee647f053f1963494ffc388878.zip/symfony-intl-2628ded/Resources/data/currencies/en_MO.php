<?php

return [
    'Names' => [
        'MOP' => [
            'MOP$',
            'Macanese Pataca',
        ],
    ],
];
