<?php

return [
    'Names' => [
        'MVR' => [
            'Rf',
            'Maldivian Rufiyaa',
        ],
    ],
];
