<?php

return [
    'Names' => [
        'PKR' => [
            'Rs',
            'Pakistani Rupee',
        ],
    ],
];
