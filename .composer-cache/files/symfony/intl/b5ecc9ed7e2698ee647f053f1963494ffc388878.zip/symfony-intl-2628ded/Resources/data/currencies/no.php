<?php

return [
    'Names' => [
        'ADP' => [
            'ADP',
            'andorranske pesetas',
        ],
        'AED' => [
            'AED',
            'emiratarabiske dirham',
        ],
        'AFA' => [
            'AFA',
            'afgansk afghani (1927–2002)',
        ],
        'AFN' => [
            'AFN',
            'afghanske afghani',
        ],
        'ALK' => [
            'ALK',
            'albanske lek (1946–1965)',
        ],
        'ALL' => [
            'ALL',
            'albanske lek',
        ],
        'AMD' => [
            'AMD',
            'armenske dram',
        ],
        'ANG' => [
            'ANG',
            'nederlandske antillegylden',
        ],
        'AOA' => [
            'AOA',
            'angolanske kwanza',
        ],
        'AOK' => [
            'AOK',
            'angolanske kwanza (1977–1990)',
        ],
        'AON' => [
            'AON',
            'angolanske nye kwanza (1990–2000)',
        ],
        'AOR' => [
            'AOR',
            'angolanske omjusterte kwanza (1995–1999)',
        ],
        'ARA' => [
            'ARA',
            'argentinske australer',
        ],
        'ARL' => [
            'ARL',
            'argentinske peso ley',
        ],
        'ARM' => [
            'ARM',
            'argentinsk pesos (1881–1970)',
        ],
        'ARP' => [
            'ARP',
            'argentinske pesos (1983–1985)',
        ],
        'ARS' => [
            'ARS',
            'argentinske pesos',
        ],
        'ATS' => [
            'ATS',
            'østerrikske shilling',
        ],
        'AUD' => [
            'AUD',
            'australske dollar',
        ],
        'AWG' => [
            'AWG',
            'arubiske floriner',
        ],
        'AZM' => [
            'AZM',
            'aserbajdsjanske manat (1993–2006)',
        ],
        'AZN' => [
            'AZN',
            'aserbajdsjanske manat',
        ],
        'BAD' => [
            'BAD',
            'bosnisk-hercegovinske dinarer (1992–1994)',
        ],
        'BAM' => [
            'BAM',
            'bosnisk-hercegovinske konvertible mark',
        ],
        'BAN' => [
            'BAN',
            'nye bosnisk-hercegovinske dinarer (1994–1997)',
        ],
        'BBD' => [
            'BBD',
            'barbadiske dollar',
        ],
        'BDT' => [
            'BDT',
            'bangladeshiske taka',
        ],
        'BEC' => [
            'BEC',
            'belgiske franc (konvertible)',
        ],
        'BEF' => [
            'BEF',
            'belgiske franc',
        ],
        'BEL' => [
            'BEL',
            'belgiske franc (finansielle)',
        ],
        'BGL' => [
            'BGL',
            'bulgarske lev (hard)',
        ],
        'BGM' => [
            'BGM',
            'bulgarske lev (sosialist)',
        ],
        'BGN' => [
            'BGN',
            'bulgarske lev',
        ],
        'BGO' => [
            'BGO',
            'bulgarske lev (1879–1952)',
        ],
        'BHD' => [
            'BHD',
            'bahrainske dinarer',
        ],
        'BIF' => [
            'BIF',
            'burundiske franc',
        ],
        'BMD' => [
            'BMD',
            'bermudiske dollar',
        ],
        'BND' => [
            'BND',
            'bruneiske dollar',
        ],
        'BOB' => [
            'BOB',
            'bolivianske boliviano',
        ],
        'BOL' => [
            'BOL',
            'bolivianske boliviano (1863–1963)',
        ],
        'BOP' => [
            'BOP',
            'bolivianske pesos',
        ],
        'BOV' => [
            'BOV',
            'bolivianske mvdol',
        ],
        'BRB' => [
            'BRB',
            'brasilianske cruzeiro novo (1967–1986)',
        ],
        'BRC' => [
            'BRC',
            'brasilianske cruzados (1986–1989)',
        ],
        'BRE' => [
            'BRE',
            'brasilianske cruzeiro (1990–1993)',
        ],
        'BRL' => [
            'BRL',
            'brasilianske real',
        ],
        'BRN' => [
            'BRN',
            'brasilianske cruzado novo (1989–1990)',
        ],
        'BRR' => [
            'BRR',
            'brasilianske cruzeiro (1993–1994)',
        ],
        'BRZ' => [
            'BRZ',
            'brasilianske cruzeiro (1942–1967)',
        ],
        'BSD' => [
            'BSD',
            'bahamanske dollar',
        ],
        'BTN' => [
            'BTN',
            'bhutanske ngultrum',
        ],
        'BUK' => [
            'BUK',
            'burmesiske kyat',
        ],
        'BWP' => [
            'BWP',
            'botswanske pula',
        ],
        'BYB' => [
            'BYB',
            'hviterussiske nye rubler (1994–1999)',
        ],
        'BYN' => [
            'BYN',
            'nye belarusiske rubler',
        ],
        'BYR' => [
            'BYR',
            'hviterussiske rubler (2000–2016)',
        ],
        'BZD' => [
            'BZD',
            'beliziske dollar',
        ],
        'CAD' => [
            'CAD',
            'kanadiske dollar',
        ],
        'CDF' => [
            'CDF',
            'kongolesiske franc',
        ],
        'CHE' => [
            'CHE',
            'WIR euro',
        ],
        'CHF' => [
            'CHF',
            'sveitsiske franc',
        ],
        'CHW' => [
            'CHW',
            'WIR franc',
        ],
        'CLE' => [
            'CLE',
            'chilenske escudo',
        ],
        'CLF' => [
            'CLF',
            'chilenske unidades de fomento',
        ],
        'CLP' => [
            'CLP',
            'chilenske pesos',
        ],
        'CNH' => [
            'CNH',
            'kinesiske yuan (offshore)',
        ],
        'CNX' => [
            'CNX',
            'Kinas folkebank dollar',
        ],
        'CNY' => [
            'CNY',
            'kinesiske yuan',
        ],
        'COP' => [
            'COP',
            'colombianske pesos',
        ],
        'COU' => [
            'COU',
            'colombianske unidad de valor real',
        ],
        'CRC' => [
            'CRC',
            'costaricanske colón',
        ],
        'CSD' => [
            'CSD',
            'serbiske dinarer (2002–2006)',
        ],
        'CSK' => [
            'CSK',
            'tsjekkoslovakiske koruna (hard)',
        ],
        'CUC' => [
            'CUC',
            'kubanske konvertible pesos',
        ],
        'CUP' => [
            'CUP',
            'kubanske pesos',
        ],
        'CVE' => [
            'CVE',
            'kappverdiske escudos',
        ],
        'CYP' => [
            'CYP',
            'kypriotiske pund',
        ],
        'CZK' => [
            'CZK',
            'tsjekkiske koruna',
        ],
        'DDM' => [
            'DDM',
            'østtyske mark',
        ],
        'DEM' => [
            'DEM',
            'tyske mark',
        ],
        'DJF' => [
            'DJF',
            'djiboutiske franc',
        ],
        'DKK' => [
            'DKK',
            'danske kroner',
        ],
        'DOP' => [
            'DOP',
            'dominikanske pesos',
        ],
        'DZD' => [
            'DZD',
            'algeriske dinarer',
        ],
        'ECS' => [
            'ECS',
            'ecuadorianske sucre',
        ],
        'ECV' => [
            'ECV',
            'ecuadorianske unidad de valor constante (UVC)',
        ],
        'EEK' => [
            'EEK',
            'estiske kroon',
        ],
        'EGP' => [
            'EGP',
            'egyptiske pund',
        ],
        'ERN' => [
            'ERN',
            'eritreiske nakfa',
        ],
        'ESA' => [
            'ESA',
            'spanske peseta (A–konto)',
        ],
        'ESB' => [
            'ESB',
            'spanske peseta (konvertibel konto)',
        ],
        'ESP' => [
            'ESP',
            'spanske peseta',
        ],
        'ETB' => [
            'ETB',
            'etiopiske birr',
        ],
        'EUR' => [
            '€',
            'euro',
        ],
        'FIM' => [
            'FIM',
            'finske mark',
        ],
        'FJD' => [
            'FJD',
            'fijianske dollar',
        ],
        'FKP' => [
            'FKP',
            'falklandspund',
        ],
        'FRF' => [
            'FRF',
            'franske franc',
        ],
        'GBP' => [
            '£',
            'britiske pund',
        ],
        'GEK' => [
            'GEK',
            'georgiske kupon larit',
        ],
        'GEL' => [
            'GEL',
            'georgiske lari',
        ],
        'GHC' => [
            'GHC',
            'ghanesisk cedi (1979–2007)',
        ],
        'GHS' => [
            'GHS',
            'ghanesiske cedi',
        ],
        'GIP' => [
            'GIP',
            'gibraltarske pund',
        ],
        'GMD' => [
            'GMD',
            'gambiske dalasi',
        ],
        'GNF' => [
            'GNF',
            'guineanske franc',
        ],
        'GNS' => [
            'GNS',
            'guineanske syli',
        ],
        'GQE' => [
            'GQE',
            'ekvatorialguineanske ekwele guineana',
        ],
        'GRD' => [
            'GRD',
            'greske drakmer',
        ],
        'GTQ' => [
            'GTQ',
            'guatemalanske quetzal',
        ],
        'GWE' => [
            'GWE',
            'portugisiske guinea escudo',
        ],
        'GWP' => [
            'GWP',
            'Guinea-Bissau-pesos',
        ],
        'GYD' => [
            'GYD',
            'guyanske dollar',
        ],
        'HKD' => [
            'HKD',
            'Hongkong-dollar',
        ],
        'HNL' => [
            'HNL',
            'honduranske lempira',
        ],
        'HRD' => [
            'HRD',
            'kroatiske dinarer',
        ],
        'HRK' => [
            'HRK',
            'kroatiske kuna',
        ],
        'HTG' => [
            'HTG',
            'haitiske gourde',
        ],
        'HUF' => [
            'HUF',
            'ungarske forinter',
        ],
        'IDR' => [
            'IDR',
            'indonesiske rupier',
        ],
        'IEP' => [
            'IEP',
            'irske pund',
        ],
        'ILP' => [
            'ILP',
            'israelske pund',
        ],
        'ILR' => [
            'ILR',
            'israelske shekler (1980–1985)',
        ],
        'ILS' => [
            'ILS',
            'nye israelske shekler',
        ],
        'INR' => [
            'INR',
            'indiske rupier',
        ],
        'IQD' => [
            'IQD',
            'irakske dinarer',
        ],
        'IRR' => [
            'IRR',
            'iranske rialer',
        ],
        'ISJ' => [
            'ISJ',
            'islandske kroner (1918–1981)',
        ],
        'ISK' => [
            'ISK',
            'islandske kroner',
        ],
        'ITL' => [
            'ITL',
            'italienske lire',
        ],
        'JMD' => [
            'JMD',
            'jamaikanske dollar',
        ],
        'JOD' => [
            'JOD',
            'jordanske dinarer',
        ],
        'JPY' => [
            'JPY',
            'japanske yen',
        ],
        'KES' => [
            'KES',
            'kenyanske shilling',
        ],
        'KGS' => [
            'KGS',
            'kirgisiske som',
        ],
        'KHR' => [
            'KHR',
            'kambodsjanske riel',
        ],
        'KMF' => [
            'KMF',
            'komoriske franc',
        ],
        'KPW' => [
            'KPW',
            'nordkoreanske won',
        ],
        'KRH' => [
            'KRH',
            'sørkoreanske hwan (1953–1962)',
        ],
        'KRO' => [
            'KRO',
            'sørkoreanske won (1945–1953)',
        ],
        'KRW' => [
            'KRW',
            'sørkoreanske won',
        ],
        'KWD' => [
            'KWD',
            'kuwaitiske dinarer',
        ],
        'KYD' => [
            'KYD',
            'caymanske dollar',
        ],
        'KZT' => [
            'KZT',
            'kasakhstanske tenge',
        ],
        'LAK' => [
            'LAK',
            'laotiske kip',
        ],
        'LBP' => [
            'LBP',
            'libanesiske pund',
        ],
        'LKR' => [
            'LKR',
            'srilankiske rupier',
        ],
        'LRD' => [
            'LRD',
            'liberiske dollar',
        ],
        'LSL' => [
            'LSL',
            'lesothiske loti',
        ],
        'LTL' => [
            'LTL',
            'litauiske litas',
        ],
        'LTT' => [
            'LTT',
            'litauiske talonas',
        ],
        'LUC' => [
            'LUC',
            'luxemburgske konvertible franc',
        ],
        'LUF' => [
            'LUF',
            'luxemburgske franc',
        ],
        'LUL' => [
            'LUL',
            'luxemburgske finansielle franc',
        ],
        'LVL' => [
            'LVL',
            'latviske lats',
        ],
        'LVR' => [
            'LVR',
            'latviske rubler',
        ],
        'LYD' => [
            'LYD',
            'libyske dinarer',
        ],
        'MAD' => [
            'MAD',
            'marokkanske dirham',
        ],
        'MAF' => [
            'MAF',
            'marokkanske franc',
        ],
        'MCF' => [
            'MCF',
            'monegaskiske franc',
        ],
        'MDC' => [
            'MDC',
            'moldovske cupon',
        ],
        'MDL' => [
            'MDL',
            'moldovske leu',
        ],
        'MGA' => [
            'MGA',
            'madagassiske ariary',
        ],
        'MGF' => [
            'MGF',
            'madagassiske franc',
        ],
        'MKD' => [
            'MKD',
            'makedonske denarer',
        ],
        'MKN' => [
            'MKN',
            'makedonske denarer (1992–1993)',
        ],
        'MLF' => [
            'MLF',
            'maliske franc',
        ],
        'MMK' => [
            'MMK',
            'myanmarske kyat',
        ],
        'MNT' => [
            'MNT',
            'mongolske tugrik',
        ],
        'MOP' => [
            'MOP',
            'makaoiske pataca',
        ],
        'MRO' => [
            'MRO',
            'mauritanske ouguiya (1973–2017)',
        ],
        'MRU' => [
            'MRU',
            'mauritanske ouguiya',
        ],
        'MTL' => [
            'MTL',
            'maltesiske lira',
        ],
        'MTP' => [
            'MTP',
            'maltesiske pund',
        ],
        'MUR' => [
            'MUR',
            'mauritiske rupier',
        ],
        'MVP' => [
            'MVP',
            'maldiviske rupier',
        ],
        'MVR' => [
            'MVR',
            'maldiviske rufiyaa',
        ],
        'MWK' => [
            'MWK',
            'malawiske kwacha',
        ],
        'MXN' => [
            'MXN',
            'meksikanske pesos',
        ],
        'MXP' => [
            'MXP',
            'meksikanske sølvpesos (1861–1992)',
        ],
        'MXV' => [
            'MXV',
            'meksikanske unidad de inversion (UDI)',
        ],
        'MYR' => [
            'MYR',
            'malaysiske ringgit',
        ],
        'MZE' => [
            'MZE',
            'mosambikiske escudo',
        ],
        'MZM' => [
            'MZM',
            'gamle mosambikiske metical',
        ],
        'MZN' => [
            'MZN',
            'mosambikiske metical',
        ],
        'NAD' => [
            'NAD',
            'namibiske dollar',
        ],
        'NGN' => [
            'NGN',
            'nigerianske naira',
        ],
        'NIC' => [
            'NIC',
            'nicaraguanske cordoba (1988–1991)',
        ],
        'NIO' => [
            'NIO',
            'nicaraguanske córdoba',
        ],
        'NLG' => [
            'NLG',
            'nederlandske gylden',
        ],
        'NOK' => [
            'kr',
            'norske kroner',
        ],
        'NPR' => [
            'NPR',
            'nepalske rupier',
        ],
        'NZD' => [
            'NZD',
            'newzealandske dollar',
        ],
        'OMR' => [
            'OMR',
            'omanske rialer',
        ],
        'PAB' => [
            'PAB',
            'panamanske balboa',
        ],
        'PEI' => [
            'PEI',
            'peruanske inti',
        ],
        'PEN' => [
            'PEN',
            'peruanske sol',
        ],
        'PES' => [
            'PES',
            'peruanske sol (1863–1965)',
        ],
        'PGK' => [
            'PGK',
            'papuanske kina',
        ],
        'PHP' => [
            'PHP',
            'filippinske pesos',
        ],
        'PKR' => [
            'PKR',
            'pakistanske rupier',
        ],
        'PLN' => [
            'PLN',
            'polske zloty',
        ],
        'PLZ' => [
            'PLZ',
            'polske zloty (1950–1995)',
        ],
        'PTE' => [
            'PTE',
            'portugisiske escudo',
        ],
        'PYG' => [
            'PYG',
            'paraguayanske guarani',
        ],
        'QAR' => [
            'QAR',
            'qatarske rialer',
        ],
        'RHD' => [
            'RHD',
            'rhodesiske dollar',
        ],
        'ROL' => [
            'ROL',
            'rumenske leu (1952–2006)',
        ],
        'RON' => [
            'RON',
            'rumenske leu',
        ],
        'RSD' => [
            'RSD',
            'serbiske dinarer',
        ],
        'RUB' => [
            'RUB',
            'russiske rubler',
        ],
        'RUR' => [
            'RUR',
            'russiske rubler (1991–1998)',
        ],
        'RWF' => [
            'RWF',
            'rwandiske franc',
        ],
        'SAR' => [
            'SAR',
            'saudiarabiske riyaler',
        ],
        'SBD' => [
            'SBD',
            'salomonske dollar',
        ],
        'SCR' => [
            'SCR',
            'seychelliske rupier',
        ],
        'SDD' => [
            'SDD',
            'sudanesiske dinarer (1992–2007)',
        ],
        'SDG' => [
            'SDG',
            'sudanske pund',
        ],
        'SDP' => [
            'SDP',
            'sudanesiske pund',
        ],
        'SEK' => [
            'SEK',
            'svenske kroner',
        ],
        'SGD' => [
            'SGD',
            'singaporske dollar',
        ],
        'SHP' => [
            'SHP',
            'sankthelenske pund',
        ],
        'SIT' => [
            'SIT',
            'slovenske tolar',
        ],
        'SKK' => [
            'SKK',
            'slovakiske koruna',
        ],
        'SLE' => [
            'SLE',
            'sierraleonske leone',
        ],
        'SLL' => [
            'SLL',
            'sierraleonske leone (1964—2022)',
        ],
        'SOS' => [
            'SOS',
            'somaliske shilling',
        ],
        'SRD' => [
            'SRD',
            'surinamske dollar',
        ],
        'SRG' => [
            'SRG',
            'surinamske gylden',
        ],
        'SSP' => [
            'SSP',
            'sørsudanske pund',
        ],
        'STD' => [
            'STD',
            'saotomesiske dobra (1977–2017)',
        ],
        'STN' => [
            'STN',
            'saotomesiske dobra',
        ],
        'SUR' => [
            'SUR',
            'sovjetiske rubler',
        ],
        'SVC' => [
            'SVC',
            'salvadoranske colon',
        ],
        'SYP' => [
            'SYP',
            'syriske pund',
        ],
        'SZL' => [
            'SZL',
            'swazilandske lilangeni',
        ],
        'THB' => [
            'THB',
            'thailandske baht',
        ],
        'TJR' => [
            'TJR',
            'tadsjikiske rubler',
        ],
        'TJS' => [
            'TJS',
            'tadsjikiske somoni',
        ],
        'TMM' => [
            'TMM',
            'turkmenske manat (1993–2009)',
        ],
        'TMT' => [
            'TMT',
            'turkmenske manat',
        ],
        'TND' => [
            'TND',
            'tunisiske dinarer',
        ],
        'TOP' => [
            'TOP',
            'tonganske paʻanga',
        ],
        'TPE' => [
            'TPE',
            'timoresiske escudo',
        ],
        'TRL' => [
            'TRL',
            'tyrkiske lire (1922–2005)',
        ],
        'TRY' => [
            'TRY',
            'tyrkiske lire',
        ],
        'TTD' => [
            'TTD',
            'trinidadiske dollar',
        ],
        'TWD' => [
            'TWD',
            'nye taiwanske dollar',
        ],
        'TZS' => [
            'TZS',
            'tanzanianske shilling',
        ],
        'UAH' => [
            'UAH',
            'ukrainske hryvnia',
        ],
        'UAK' => [
            'UAK',
            'ukrainske karbovanetz',
        ],
        'UGS' => [
            'UGS',
            'ugandiske shilling (1966–1987)',
        ],
        'UGX' => [
            'UGX',
            'ugandiske shilling',
        ],
        'USD' => [
            'USD',
            'amerikanske dollar',
        ],
        'USN' => [
            'USN',
            'amerikanske dollar (neste dag)',
        ],
        'USS' => [
            'USS',
            'amerikanske dollar (samme dag)',
        ],
        'UYI' => [
            'UYI',
            'uruguyanske pesos (indekserte enheter)',
        ],
        'UYP' => [
            'UYP',
            'uruguayanske pesos (1975–1993)',
        ],
        'UYU' => [
            'UYU',
            'uruguayanske pesos',
        ],
        'UZS' => [
            'UZS',
            'usbekiske som',
        ],
        'VEB' => [
            'VEB',
            'venezuelanske bolivar (1871–2008)',
        ],
        'VEF' => [
            'VEF',
            'venezuelanske bolivar (2008–2018)',
        ],
        'VES' => [
            'VES',
            'venezuelanske bolivar',
        ],
        'VND' => [
            'VND',
            'vietnamesiske dong',
        ],
        'VNN' => [
            'VNN',
            'vietnamesiske dong (1978–1985)',
        ],
        'VUV' => [
            'VUV',
            'vanuatiske vatu',
        ],
        'WST' => [
            'WST',
            'samoanske tala',
        ],
        'XAF' => [
            'XAF',
            'sentralafrikanske CFA-franc',
        ],
        'XCD' => [
            'XCD',
            'østkaribiske dollar',
        ],
        'XEU' => [
            'XEU',
            'europeisk valutaenhet',
        ],
        'XFO' => [
            'XFO',
            'franske gullfranc',
        ],
        'XFU' => [
            'XFU',
            'franske UIC-franc',
        ],
        'XOF' => [
            'F CFA',
            'vestafrikanske CFA-franc',
        ],
        'XPF' => [
            'XPF',
            'CFP-franc',
        ],
        'XRE' => [
            'XRE',
            'RINET-fond',
        ],
        'YDD' => [
            'YDD',
            'jemenittiske dinarer',
        ],
        'YER' => [
            'YER',
            'jemenittiske rialer',
        ],
        'YUD' => [
            'YUD',
            'jugoslaviske dinarer (hard)',
        ],
        'YUM' => [
            'YUM',
            'jugoslaviske noviy-dinarer',
        ],
        'YUN' => [
            'YUN',
            'jugoslaviske konvertible dinarer',
        ],
        'YUR' => [
            'YUR',
            'jugoslaviske reformerte dinarer (1992–1993)',
        ],
        'ZAL' => [
            'ZAL',
            'sørafrikanske rand (finansielle)',
        ],
        'ZAR' => [
            'ZAR',
            'sørafrikanske rand',
        ],
        'ZMK' => [
            'ZMK',
            'zambiske kwacha (1968–2012)',
        ],
        'ZMW' => [
            'ZMW',
            'zambiske kwacha',
        ],
        'ZRN' => [
            'ZRN',
            'zairiske nye zaire',
        ],
        'ZRZ' => [
            'ZRZ',
            'zairiske zaire',
        ],
        'ZWD' => [
            'ZWD',
            'zimbabwiske dollar (1980–2008)',
        ],
        'ZWL' => [
            'ZWL',
            'zimbabwisk dollar (2009)',
        ],
        'ZWR' => [
            'ZWR',
            'zimbabwisk dollar (2008)',
        ],
    ],
];
